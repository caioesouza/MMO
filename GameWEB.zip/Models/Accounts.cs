﻿namespace $safeprojectname$.Models
{
    public class Accounts
    {
        public int Id { get; set; }
        public string User { get; set; }
        public string Passwrod { get; set; }
    }
}