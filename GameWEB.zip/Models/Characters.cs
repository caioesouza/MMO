﻿namespace $safeprojectname$.Models
{
    public class Characters
    {
        public int Id { get; set; }
        public string Name { get; set; }
        #region Cosmetic
        public string SkinColor { get; set; }
        #endregion
        #region Attack
        public double Intelligence { get; set; }
        public double Agility { get; set; }
        public double Strength { get; set; }
        #endregion
        #region Defense
        public double Resistance { get; set; }
        #endregion
        #region HP/MP
        public double Stamina { get; set; }
        #endregion
        #region Location
        public double LocationX { get; set; }
        public double LocationY { get; set; }
        public double LocationZ { get; set; }
        #endregion
        public virtual Accounts Account { get; set; }

        public Characters()//constrctor with default attributes to put in database
        {
            this.Agility = 1;
            this.Intelligence = 1;
            this.Strength = 1;
            this.Resistance = 10;
            this.Stamina = 100;
            this.LocationX = -886;
            this.LocationY = -346;
            this.LocationZ = -130;
        }


    }
}