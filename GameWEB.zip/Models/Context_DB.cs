﻿using System.Data.Entity;

namespace $safeprojectname$.Models
{
    public class Context_DB : DbContext
    {
        public DbSet<Accounts> Accounts { get; set; }
        public DbSet<Characters> Characters { get; set; }
        public DbSet<Objects> Objects { get; set; }

        public Context_DB()//insert into first run of database
        {
            if(this.Objects.CountAsync().Result == 0)
            {
                var Mob0001 = new Objects();
                Mob0001.Name = "Mob0001";
                Mob0001.LocationX = -800;
                Mob0001.LocationY = -610;
                Mob0001.LocationZ = 212;
                Mob0001.ScaleX = 1;
                Mob0001.ScaleY = 1;
                Mob0001.ScaleZ = 1;
                Mob0001.Stamina = 130;

                this.Objects.Add(Mob0001);
                this.SaveChanges();
            }
        }
    }
}