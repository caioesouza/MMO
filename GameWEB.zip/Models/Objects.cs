﻿namespace $safeprojectname$.Models
{
    public class Objects
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Stamina { get; set; }
        public double LocationX { get; set; }
        public double LocationY { get; set; }
        public double LocationZ { get; set; }
        public double RotationX { get; set; }
        public double RotationY { get; set; }
        public double RotationZ { get; set; }
        public double ScaleX { get; set; }
        public double ScaleY { get; set; }
        public double ScaleZ { get; set; }
    }
}