﻿using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class CharactersController : Controller
    {
        public Context_DB db = new Context_DB();

        #region Controller
        // GET: Characters
        public ActionResult Index()
        {
            return View(db.Characters.ToList());
        }

        // GET: Characters/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Characters characters = db.Characters.Find(id);
            if (characters == null)
            {
                return HttpNotFound();
            }
            return View(characters);
        }

        // GET: Characters/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Characters/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,SkinColor,Intelligence,Agility,Strength,Resistance,Stamina,LocationX,LocationY,LocationZ")] Characters characters)
        {
            if (ModelState.IsValid)
            {
                db.Characters.Add(characters);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(characters);
        }

        // GET: Characters/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Characters characters = db.Characters.Find(id);
            if (characters == null)
            {
                return HttpNotFound();
            }
            return View(characters);
        }

        // POST: Characters/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,SkinColor,Intelligence,Agility,Strength,Resistance,Stamina,LocationX,LocationY,LocationZ")] Characters characters)
        {
            if (ModelState.IsValid)
            {
                db.Entry(characters).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(characters);
        }

        // GET: Characters/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Characters characters = db.Characters.Find(id);
            if (characters == null)
            {
                return HttpNotFound();
            }
            return View(characters);
        }

        // POST: Characters/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Characters characters = db.Characters.Find(id);
            db.Characters.Remove(characters);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
#endregion

        #region Characters

        public JsonResult checkAlrightExistName(string name)
        {
            foreach (var character in db.Characters)
            {
                if (character.Name.Equals(name))//name alright exist in db
                    return Json(new { Resp = "NOT" });
            }
            return Json(new { Resp = "OK" });//not exist
        }
        public JsonResult createCharacter(int idAccount, string name, string skinColor)
        {
            var character = new Characters();

            character.Account = db.Accounts.Where(c => c.Id == idAccount).First();
            character.Name = name;
            character.SkinColor = skinColor;

            db.Characters.Add(character);
            db.SaveChanges();

            return getCharacter(character.Id);
        }
        public JsonResult haveCharacter(int idAccount)
        {
            foreach (var character in db.Characters)
            {
                if (character.Account.Id == idAccount)
                {
                    return getCharacter(character.Id);
                }
            }
            return Json(new { Resp = "NOT" });//not exist
        }

        #region Update Character
        public JsonResult updateIntelligence(int idCharacter, double intelligence)
        {
            Characters character = db.Characters.First(c => c.Id == idCharacter);

            character.Intelligence = intelligence;
            db.SaveChanges();

            return getCharacter(character.Id);
        }
        public JsonResult updateAgility(int idCharacter, double agility)
        {
            Characters character = db.Characters.First(c => c.Id == idCharacter);

            character.Agility = agility;
            db.SaveChanges();

            return getCharacter(character.Id);
        }
        public JsonResult updateStrength(int idCharacter, double strength)
        {
            Characters character = db.Characters.First(c => c.Id == idCharacter);

            character.Strength = strength;
            db.SaveChanges();

            return getCharacter(character.Id);
        }
        public JsonResult updateResistance(int idCharacter, double resistance)
        {
            Characters character = db.Characters.First(c => c.Id == idCharacter);

            character.Resistance = resistance;
            db.SaveChanges();

            return getCharacter(character.Id);
        }
        public JsonResult updateStamina(int idCharacter, double stamina)
        {
            Characters character = db.Characters.First(c => c.Id == idCharacter);

            character.Stamina = stamina;
            db.SaveChanges();

            return getCharacter(character.Id);
        }
        public JsonResult updateLocation(int idCharacter, double locationX, double locationY, double locationZ)
        {
            Characters character = db.Characters.First(c => c.Id == idCharacter);

            character.LocationX = locationX;
            character.LocationY = locationY;
            character.LocationZ = locationZ;
            db.SaveChanges();

            return getCharacter(character.Id);
        }
        public JsonResult getCharacter(int idCharacter)
        {
            Characters character = db.Characters.First(c => c.Id == idCharacter);
            return Json(new 
            { 
                                Resp = "OK",
                                IdAccount = character.Account.Id,
                                IdCharacter = character.Id,
                                CharacterName = character.Name,
                                CharacterSkinColor = character.SkinColor,
                                CharacterIntelligence = character.Intelligence,
                                CharacterAgility = character.Agility,
                                CharacterStrenght = character.Strength,
                                CharacterResistance = character.Resistance,
                                CharacterStamina = character.Stamina,
                                CharacterLocationX = character.LocationX,
                                CharacterLocationY = character.LocationY,
                                CharacterLocationZ = character.LocationZ
            });
        }
        #endregion
        #endregion
    }
}
