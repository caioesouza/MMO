﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class ObjectsController : Controller
    {
        private Context_DB db = new Context_DB();
        #region Controller
        // GET: Objects
        public ActionResult Index()
        {
            return View(db.Objects.ToList());
        }

        // GET: Objects/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Objects objects = db.Objects.Find(id);
            if (objects == null)
            {
                return HttpNotFound();
            }
            return View(objects);
        }

        // GET: Objects/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Objects/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name")] Objects objects)
        {
            if (ModelState.IsValid)
            {
                db.Objects.Add(objects);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(objects);
        }

        // GET: Objects/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Objects objects = db.Objects.Find(id);
            if (objects == null)
            {
                return HttpNotFound();
            }
            return View(objects);
        }

        // POST: Objects/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name")] Objects objects)
        {
            if (ModelState.IsValid)
            {
                db.Entry(objects).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(objects);
        }

        // GET: Objects/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Objects objects = db.Objects.Find(id);
            if (objects == null)
            {
                return HttpNotFound();
            }
            return View(objects);
        }

        // POST: Objects/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Objects objects = db.Objects.Find(id);
            db.Objects.Remove(objects);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        #endregion

        #region Objects
        public JsonResult getObjects()
        {
            var temp = db.Objects.ToArray();
            return Json(new { Resp = "OK", ObjectsArray = temp });
        }
        public JsonResult getStamina(string name)
        {
            var temp = db.Objects.First(c => c.Name == name);
            return Json(new { Resp = "OK", ObjectStamina = temp.Stamina });
        }
        #endregion
    }
}
