namespace $safeprojectname$.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _0006 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Objects", "Stamina", c => c.Double(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Objects", "Stamina");
        }
    }
}
