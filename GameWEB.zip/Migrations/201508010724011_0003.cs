namespace $safeprojectname$.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _0003 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Characters", "MaxStamina", c => c.Double(nullable: false));
            AddColumn("dbo.Characters", "CurrentStamina", c => c.Double(nullable: false));
            DropColumn("dbo.Characters", "Stamina");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Characters", "Stamina", c => c.Double(nullable: false));
            DropColumn("dbo.Characters", "CurrentStamina");
            DropColumn("dbo.Characters", "MaxStamina");
        }
    }
}
