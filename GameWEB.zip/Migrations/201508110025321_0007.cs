namespace $safeprojectname$.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _0007 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Characters", "Stamina", c => c.Double(nullable: false));
            DropColumn("dbo.Characters", "MaxStamina");
            DropColumn("dbo.Characters", "CurrentStamina");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Characters", "CurrentStamina", c => c.Double(nullable: false));
            AddColumn("dbo.Characters", "MaxStamina", c => c.Double(nullable: false));
            DropColumn("dbo.Characters", "Stamina");
        }
    }
}
