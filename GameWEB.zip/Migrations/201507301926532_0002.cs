namespace $safeprojectname$.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _0002 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Accounts", "User", c => c.String());
            AddColumn("dbo.Accounts", "Passwrod", c => c.String());
            AddColumn("dbo.Characters", "Name", c => c.String());
            AddColumn("dbo.Characters", "SkinColor", c => c.String());
            AddColumn("dbo.Characters", "Intelligence", c => c.Double(nullable: false));
            AddColumn("dbo.Characters", "Agility", c => c.Double(nullable: false));
            AddColumn("dbo.Characters", "Strength", c => c.Double(nullable: false));
            AddColumn("dbo.Characters", "Resistance", c => c.Double(nullable: false));
            AddColumn("dbo.Characters", "Stamina", c => c.Double(nullable: false));
            AddColumn("dbo.Characters", "LocationX", c => c.Double(nullable: false));
            AddColumn("dbo.Characters", "LocationY", c => c.Double(nullable: false));
            AddColumn("dbo.Characters", "LocationZ", c => c.Double(nullable: false));
            AddColumn("dbo.Characters", "Account_Id", c => c.Int());
            CreateIndex("dbo.Characters", "Account_Id");
            AddForeignKey("dbo.Characters", "Account_Id", "dbo.Accounts", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Characters", "Account_Id", "dbo.Accounts");
            DropIndex("dbo.Characters", new[] { "Account_Id" });
            DropColumn("dbo.Characters", "Account_Id");
            DropColumn("dbo.Characters", "LocationZ");
            DropColumn("dbo.Characters", "LocationY");
            DropColumn("dbo.Characters", "LocationX");
            DropColumn("dbo.Characters", "Stamina");
            DropColumn("dbo.Characters", "Resistance");
            DropColumn("dbo.Characters", "Strength");
            DropColumn("dbo.Characters", "Agility");
            DropColumn("dbo.Characters", "Intelligence");
            DropColumn("dbo.Characters", "SkinColor");
            DropColumn("dbo.Characters", "Name");
            DropColumn("dbo.Accounts", "Passwrod");
            DropColumn("dbo.Accounts", "User");
        }
    }
}
