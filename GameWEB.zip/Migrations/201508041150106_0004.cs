namespace $safeprojectname$.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _0004 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Objects",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Transform_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Transforms", t => t.Transform_Id)
                .Index(t => t.Transform_Id);
            
            CreateTable(
                "dbo.Transforms",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        LocationX = c.Double(nullable: false),
                        LocationY = c.Double(nullable: false),
                        LocationZ = c.Double(nullable: false),
                        RotationX = c.Double(nullable: false),
                        RotationY = c.Double(nullable: false),
                        RotationZ = c.Double(nullable: false),
                        ScaleX = c.Double(nullable: false),
                        ScaleY = c.Double(nullable: false),
                        ScaleZ = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Objects", "Transform_Id", "dbo.Transforms");
            DropIndex("dbo.Objects", new[] { "Transform_Id" });
            DropTable("dbo.Transforms");
            DropTable("dbo.Objects");
        }
    }
}
